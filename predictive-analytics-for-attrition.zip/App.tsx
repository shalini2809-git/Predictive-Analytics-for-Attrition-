import React, { useState, useEffect, createContext, useContext } from 'react';
import Dashboard from './components/Dashboard';
import { Linkedin, Instagram, Github, Twitter, Youtube, BookText, Sun, Moon, Sparkles } from 'lucide-react';

// --- THEME ---
type Theme = 'light' | 'dark' | 'bright';
interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
};

const ThemeProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
    const [theme, setTheme] = useState<Theme>(() => {
        const storedTheme = localStorage.getItem('app-theme');
        return (storedTheme as Theme) || 'light';
    });

    useEffect(() => {
        const root = window.document.documentElement;
        root.classList.remove('light', 'dark', 'bright');
        root.classList.add(theme);
        localStorage.setItem('app-theme', theme);
    }, [theme]);
    
    return (
        <ThemeContext.Provider value={{ theme, setTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

// --- SOCIAL LINKS ---
const socialLinks = [
    { name: 'Blog', href: 'https://hereandnowai.com/blog', icon: BookText },
    { name: 'LinkedIn', href: 'https://www.linkedin.com/company/hereandnowai/', icon: Linkedin },
    { name: 'Instagram', href: 'https://instagram.com/hereandnow_ai', icon: Instagram },
    { name: 'GitHub', href: 'https://github.com/hereandnowai', icon: Github },
    { name: 'X', href: 'https://x.com/hereandnow_ai', icon: Twitter },
    { name: 'YouTube', href: 'https://youtube.com/@hereandnow_ai', icon: Youtube },
];


const ThemeSwitcher: React.FC = () => {
    const { theme, setTheme } = useTheme();

    const themes: { name: Theme, icon: React.FC<any> }[] = [
        { name: 'light', icon: Sun },
        { name: 'dark', icon: Moon },
        { name: 'bright', icon: Sparkles },
    ];

    return (
        <div className="flex items-center space-x-2 rounded-full bg-black/20 p-1">
            {themes.map(t => (
                <button 
                    key={t.name}
                    onClick={() => setTheme(t.name)}
                    className={`p-1.5 rounded-full transition-colors ${theme === t.name ? 'bg-[var(--color-primary-hex)] text-black' : 'text-gray-400 hover:text-white'}`}
                    aria-label={`Switch to ${t.name} theme`}
                >
                    <t.icon className="h-4 w-4" />
                </button>
            ))}
        </div>
    )
}

function AppContent(): React.ReactNode {
  const { theme } = useTheme();
  return (
    <div className="min-h-screen bg-[rgb(var(--color-background))] text-[rgb(var(--color-foreground))] flex flex-col transition-colors">
      <header className="bg-[var(--color-header-bg)] shadow-lg sticky top-0 z-10 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <a href="https://hereandnowai.com" target="_blank" rel="noopener noreferrer">
                <img 
                  src="https://raw.githubusercontent.com/hereandnowai/images/refs/heads/main/logos/HNAI%20Title%20-Teal%20%26%20Golden%20Logo%20-%20DESIGN%203%20-%20Raj-07.png" 
                  alt="HERE AND NOW AI Logo" 
                  className="h-10"
                />
              </a>
              <div className="h-8 w-px bg-white/20"></div>
               <h1 className="text-xl font-semibold text-[var(--color-header-fg)]">
                Attrition Prediction Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-4">
               <p className="hidden md:block text-sm text-[rgb(var(--color-header-slogan))] italic">
                designed with passion for innovation
              </p>
              <ThemeSwitcher />
            </div>
          </div>
        </div>
      </header>
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <Dashboard theme={theme}/>
        </div>
      </main>
      <footer className="bg-[rgb(var(--color-footer-bg))] text-[rgb(var(--color-footer-fg))] text-sm mt-auto transition-colors">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                <div className="flex space-x-6">
                    {socialLinks.map((item) => (
                        <a key={item.name} href={item.href} target="_blank" rel="noopener noreferrer" className="text-[rgb(var(--color-footer-icon))] hover:text-[var(--color-primary-hex)] transition-colors">
                            <span className="sr-only">{item.name}</span>
                            <item.icon className="h-5 w-5" aria-hidden="true" />
                        </a>
                    ))}
                </div>
                 <div className="text-center md:text-right">
                    <p className="text-sm">
                        &copy; {new Date().getFullYear()} HERE AND NOW AI - Artificial Intelligence Research Institute
                    </p>
                    <p className="text-xs text-[rgb(var(--color-muted-foreground))]">
                        Developed by Shalini [AI products engineering team]
                    </p>
                </div>
            </div>
        </div>
      </footer>
    </div>
  );
}

function App(): React.ReactNode {
    return (
        <ThemeProvider>
            <AppContent />
        </ThemeProvider>
    );
}

export default App;