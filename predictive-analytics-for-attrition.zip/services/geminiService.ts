import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Employee, AttritionPrediction, ResumeAnalysis } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const generatePrompt = (employee: Employee): string => {
  return `
    Analyze the following employee data to predict attrition risk.
    You are an expert HR predictive analytics model.

    Employee Data:
    - Name: ${employee.name}
    - Department: ${employee.department}
    - Role: ${employee.role}
    - Tenure: ${employee.tenureMonths} months
    - Salary: $${employee.salary.toLocaleString()}
    - Performance Score: ${employee.performanceScore}/5
    - Engagement Score: ${employee.engagementScore}/100
    - Years Since Last Promotion: ${employee.lastPromotionYears}

    Based on this data, provide a JSON object with the following structure. Do not include any other text, markdown, or code fences.
  `;
};

const attritionPredictionSchema = {
    type: Type.OBJECT,
    properties: {
        riskScore: { 
            type: Type.INTEGER,
            description: "A score from 0 to 100 indicating attrition risk."
        },
        riskFactors: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "A list of the top 3-4 factors contributing to the risk."
        },
        retentionStrategies: {
            type: Type.ARRAY,
            description: "A list of 2-3 tailored retention strategies.",
            items: {
                type: Type.OBJECT,
                properties: {
                    strategy: { 
                        type: Type.STRING,
                        description: "The name of the strategy."
                    },
                    rationale: { 
                        type: Type.STRING,
                        description: "A brief explanation of why this strategy is recommended."
                    }
                },
                required: ["strategy", "rationale"]
            }
        }
    },
    required: ["riskScore", "riskFactors", "retentionStrategies"]
};


export const getAttritionPrediction = async (employee: Employee): Promise<AttritionPrediction> => {
  try {
    const prompt = generatePrompt(employee);
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: attritionPredictionSchema,
        temperature: 0.2,
      },
    });

    const parsedData: AttritionPrediction = JSON.parse(response.text);
    return parsedData;

  } catch (error) {
    console.error("Error fetching attrition prediction:", error);
    throw new Error("Failed to get prediction from Gemini API. Please check your API key and network connection.");
  }
};


const generateResumeAnalysisPrompt = (employee: Employee, resumeText: string): string => {
      return `
        You are an expert HR predictive analytics model specializing in talent retention.
        Your task is to re-evaluate an employee's attrition risk by analyzing their updated resume in the context of their existing employment data.

        **Existing Employee Data:**
        - Name: ${employee.name}
        - Department: ${employee.department}
        - Role: ${employee.role}
        - Tenure: ${employee.tenureMonths} months
        - Salary: $${employee.salary.toLocaleString()}
        - Performance Score: ${employee.performanceScore}/5
        - Engagement Score: ${employee.engagementScore}/100
        - Years Since Last Promotion: ${employee.lastPromotionYears}

        **Employee's Updated Resume Text:**
        """
        ${resumeText}
        """

        **Analysis Instructions:**
        1.  **Compare:** Cross-reference the resume with the existing data. Identify new information, discrepancies, and subtle cues.
        2.  **Identify Signals:** Look for both negative (job seeking) and positive (skill growth) signals.
            -   **Risk Factors:** Look for signs of active job searching (e.g., "seeking new opportunities", recently updated format, skills listed that are not used in the current role). Also, identify potential dissatisfaction if the employee seems overqualified or their career path is misaligned with their new skills.
            -   **Positive Signals:** Identify new skills, certifications, or experiences that could be valuable to the company. These represent growth and could be opportunities for internal mobility.
        3.  **Update Risk Score:** Provide a new, updated attrition risk score based on your comprehensive analysis. The original score was based only on structured data; this new score must incorporate insights from the resume.
        4.  **Summarize:** Briefly explain your reasoning.

        **Output Format:**
        Provide a JSON object with the following structure. Do not include any other text or markdown formatting.
      `;
    };

const resumeAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        updatedRiskScore: {
            type: Type.INTEGER,
            description: "The new, updated attrition risk score."
        },
        analysisSummary: {
            type: Type.STRING,
            description: "A brief summary explaining the reasoning for the updated score."
        },
        newRiskFactors: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of new risk factors identified from the resume."
        },
        positiveSignals: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of positive signals (e.g., new skills) identified from the resume."
        }
    },
    required: ["updatedRiskScore", "analysisSummary", "newRiskFactors", "positiveSignals"]
};


export const getResumeAnalysis = async (employee: Employee, resumeText: string): Promise<ResumeAnalysis> => {
    try {
        const prompt = generateResumeAnalysisPrompt(employee, resumeText);
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: resumeAnalysisSchema,
                temperature: 0.3,
            },
        });

        const parsedData: ResumeAnalysis = JSON.parse(response.text);
        return parsedData;

    } catch (error) {
        console.error("Error fetching resume analysis:", error);
        throw new Error("Failed to get analysis from Gemini API. The resume content might be invalid or there could be a network issue.");
    }
};