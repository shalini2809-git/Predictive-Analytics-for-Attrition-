import React from 'react';

interface ChartContainerProps {
  title: string;
  children: React.ReactNode;
}

const ChartContainer: React.FC<ChartContainerProps> = ({ title, children }) => {
  return (
    <div className="bg-[rgb(var(--color-card))] p-6 rounded-lg shadow-md border border-black/5 transition-colors">
      <h3 className="text-lg font-semibold mb-4 text-[rgb(var(--color-card-foreground))]">{title}</h3>
      <div className="h-full">
        {children}
      </div>
    </div>
  );
};

export default ChartContainer;