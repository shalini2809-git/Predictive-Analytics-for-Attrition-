import React, { useState } from 'react';
import { Employee, AttritionPrediction, ResumeAnalysis } from '../types';
import RiskScore from './RiskScore';
import { Loader2, AlertCircle, TrendingDown, ShieldCheck, BrainCircuit, TrendingUp } from 'lucide-react';

interface EmployeeDetailProps {
  employee: Employee | null;
  prediction: AttritionPrediction | null;
  isLoading: boolean;
  error: string | null;
  resumeAnalysis: ResumeAnalysis | null;
  onAnalyzeResume: (employee: Employee, resumeText: string) => Promise<void>;
}

const FeedbackForm: React.FC = () => {
    const [submitted, setSubmitted] = useState(false);
    if(submitted){
        return <div className="p-4 bg-green-500/10 border border-green-500/20 text-green-500 rounded-lg text-sm flex items-center">
            <ShieldCheck className="w-4 h-4 mr-2" />
            Thank you! Your feedback helps refine future predictions.
        </div>
    }

    return (
        <div className="mt-6 pt-6 border-t border-[rgb(var(--color-border))]">
            <h4 className="font-semibold text-[rgb(var(--color-foreground))] mb-2">Feedback on Retention Strategies</h4>
            <p className="text-sm text-[rgb(var(--color-muted-foreground))] mb-3">Did you implement any of these strategies?</p>
            <div className="flex space-x-3">
                 <button onClick={() => setSubmitted(true)} className="flex-1 bg-[var(--color-secondary-hex)] text-white px-4 py-2 rounded-md text-sm font-medium hover:opacity-90 transition-opacity">Implemented & Effective</button>
                 <button onClick={() => setSubmitted(true)} className="flex-1 bg-transparent border border-[var(--color-secondary-hex)] text-[var(--color-secondary-hex)] px-4 py-2 rounded-md text-sm font-medium hover:bg-[var(--color-secondary-hex)]/10 transition-colors">Not Implemented</button>
            </div>
        </div>
    )
}

interface ResumeAnalysisSectionProps {
    employee: Employee;
    analysisResult: ResumeAnalysis | null;
    onAnalyzeResume: (employee: Employee, resumeText: string) => Promise<void>;
    isLoading: boolean;
}

const ResumeAnalysisSection: React.FC<ResumeAnalysisSectionProps> = ({ employee, analysisResult, onAnalyzeResume, isLoading }) => {
    const [resumeText, setResumeText] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!resumeText.trim() || isLoading) return;
        onAnalyzeResume(employee, resumeText);
    };

    return (
        <div className="mt-6 pt-6 border-t border-[rgb(var(--color-border))]">
            <h4 className="font-semibold text-[rgb(var(--color-foreground))] mb-3 flex items-center">
                <BrainCircuit className="w-5 h-5 mr-2 text-[var(--color-primary-hex)]"/>
                Deeper Analysis with Updated Resume
            </h4>
            <form onSubmit={handleSubmit} className="space-y-3">
                <textarea
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    placeholder="Paste the employee's full resume text here for an AI-powered analysis..."
                    className="w-full h-32 p-3 text-sm bg-[rgb(var(--color-background))] border border-[rgb(var(--color-border))] rounded-md focus:ring-2 focus:ring-[var(--color-primary-hex)] focus:border-[var(--color-primary-hex)] transition-colors"
                    disabled={isLoading}
                />
                <button 
                    type="submit"
                    disabled={!resumeText.trim() || isLoading}
                    className="w-full flex items-center justify-center bg-[var(--color-primary-hex)] text-black px-4 py-2 rounded-md text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Analyze Resume'}
                </button>
            </form>

            {analysisResult && !isLoading && (
                <div className="mt-6 space-y-4">
                    <div>
                        <h5 className="font-semibold text-sm text-[rgb(var(--color-foreground))] mb-2">Analysis Summary</h5>
                        <p className="text-sm p-3 bg-[rgb(var(--color-background))] rounded-lg border border-[rgb(var(--color-border))]">{analysisResult.analysisSummary}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                           <h5 className="font-semibold text-sm text-[rgb(var(--color-foreground))] mb-2 flex items-center"><TrendingDown className="w-4 h-4 mr-2 text-red-500" />New Risk Factors</h5>
                           <ul className="space-y-2">
                                {analysisResult.newRiskFactors.map((factor, i) => (
                                    <li key={`risk-${i}`} className="text-sm p-2 bg-[rgb(var(--color-background))] rounded-md border border-[rgb(var(--color-border))]">{factor}</li>
                                ))}
                                {analysisResult.newRiskFactors.length === 0 && <li className="text-sm text-[rgb(var(--color-muted-foreground))] italic">No new risk factors identified.</li>}
                           </ul>
                        </div>
                        <div>
                           <h5 className="font-semibold text-sm text-[rgb(var(--color-foreground))] mb-2 flex items-center"><TrendingUp className="w-4 h-4 mr-2 text-green-500" />Positive Signals</h5>
                            <ul className="space-y-2">
                                {analysisResult.positiveSignals.map((signal, i) => (
                                    <li key={`signal-${i}`} className="text-sm p-2 bg-[rgb(var(--color-background))] rounded-md border border-[rgb(var(--color-border))]">{signal}</li>
                                ))}
                                {analysisResult.positiveSignals.length === 0 && <li className="text-sm text-[rgb(var(--color-muted-foreground))] italic">No new positive signals found.</li>}
                           </ul>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}


const EmployeeDetail: React.FC<EmployeeDetailProps> = ({ employee, prediction, isLoading, error, resumeAnalysis, onAnalyzeResume }) => {
  if (!employee) {
    return (
      <div className="bg-[rgb(var(--color-card))] p-6 rounded-lg shadow-md border border-black/5 h-full flex items-center justify-center transition-colors">
        <div className="text-center">
            <img src="https://raw.githubusercontent.com/hereandnowai/images/refs/heads/main/logos/caramel-face.jpeg" alt="Chatbot Face" className="w-24 h-24 mx-auto rounded-full mb-4 opacity-80" />
            <p className="text-[rgb(var(--color-muted-foreground))]">Select an employee to see details</p>
        </div>
      </div>
    );
  }

  const currentPrediction = resumeAnalysis ? { ...prediction, riskScore: resumeAnalysis.updatedRiskScore } : prediction;

  return (
    <div className="bg-[rgb(var(--color-card))] p-6 rounded-lg shadow-md border border-black/5 transition-colors">
      <div className="flex justify-between items-start">
        <div>
            <h3 className="text-xl font-bold text-[var(--color-secondary-hex)]">{employee.name}</h3>
            <p className="text-sm text-[rgb(var(--color-muted-foreground))]">{employee.role}, {employee.department}</p>
        </div>
        {isLoading && <Loader2 className="h-6 w-6 animate-spin text-[var(--color-secondary-hex)]" />}
      </div>
      
      {error && (
        <div className="mt-4 p-4 bg-red-500/10 border border-red-500/20 text-red-500 rounded-lg flex items-start">
            <AlertCircle className="w-5 h-5 mr-3 flex-shrink-0" />
            <div>
              <h4 className="font-bold">Analysis Failed</h4>
              <p className="text-sm">{error}</p>
            </div>
        </div>
      )}

      {currentPrediction && !isLoading && (
        <div className="mt-6 space-y-6">
          <div>
            <h4 className="font-semibold text-[rgb(var(--color-foreground))] mb-2">Attrition Risk Score</h4>
            <RiskScore score={currentPrediction.riskScore} size="large" />
          </div>

          <div>
            <h4 className="font-semibold text-[rgb(var(--color-foreground))] mb-3 flex items-center">
                <TrendingDown className="w-5 h-5 mr-2 text-red-500"/>
                Key Risk Factors
            </h4>
            <ul className="space-y-2">
              {currentPrediction.riskFactors.map((factor, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-red-500 mr-2 mt-1">&#8226;</span>
                  <p className="text-sm text-[rgb(var(--color-muted-foreground))]">{factor}</p>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-[rgb(var(--color-foreground))] mb-3 flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-green-500" />
                Recommended Retention Strategies
            </h4>
            <div className="space-y-3">
              {currentPrediction.retentionStrategies.map((item, index) => (
                <div key={index} className="p-3 bg-[rgb(var(--color-background))] rounded-lg border border-[rgb(var(--color-border))]">
                  <p className="font-semibold text-sm text-[rgb(var(--color-card-foreground))]">{item.strategy}</p>
                  <p className="text-sm text-[rgb(var(--color-muted-foreground))] mt-1">{item.rationale}</p>
                </div>
              ))}
            </div>
          </div>
          <FeedbackForm />
        </div>
      )}

      {prediction && !error && (
        <ResumeAnalysisSection 
          employee={employee} 
          analysisResult={resumeAnalysis}
          onAnalyzeResume={onAnalyzeResume}
          isLoading={isLoading}
        />
      )}
    </div>
  );
};

export default EmployeeDetail;