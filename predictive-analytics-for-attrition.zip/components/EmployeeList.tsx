import React from 'react';
import { Employee, AttritionPrediction } from '../types';
import RiskScore from './RiskScore';
import { Loader2 } from 'lucide-react';

interface EmployeeListProps {
  employees: Employee[];
  onSelectEmployee: (employee: Employee) => void;
  selectedEmployee: Employee | null;
  predictions: Record<number, AttritionPrediction>;
  loadingEmployeeId: number | null;
}

const EmployeeList: React.FC<EmployeeListProps> = ({ employees, onSelectEmployee, selectedEmployee, predictions, loadingEmployeeId }) => {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-[rgb(var(--color-border))]">
        <thead className="bg-[rgb(var(--color-background))]">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--color-secondary-hex)]/80 uppercase tracking-wider">Name</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--color-secondary-hex)]/80 uppercase tracking-wider">Department</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--color-secondary-hex)]/80 uppercase tracking-wider">Risk Score</th>
          </tr>
        </thead>
        <tbody className="bg-[rgb(var(--color-card))] divide-y divide-[rgb(var(--color-border))]">
          {employees.map((employee) => (
            <tr
              key={employee.id}
              onClick={() => onSelectEmployee(employee)}
              className={`cursor-pointer transition-colors duration-200 ${
                selectedEmployee?.id === employee.id
                  ? 'bg-[hsl(var(--color-primary-hsl)/0.2)] border-l-4 border-[var(--color-primary-hex)]'
                  : 'hover:bg-[rgb(var(--color-background))]'
              }`}
            >
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-[rgb(var(--color-card-foreground))]">{employee.name}</div>
                <div className="text-sm text-[rgb(var(--color-muted-foreground))]">{employee.role}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-[rgb(var(--color-muted-foreground))]">{employee.department}</td>
              <td className="px-6 py-4 whitespace-nowrap">
                {loadingEmployeeId === employee.id ? (
                  <div className="flex items-center space-x-2">
                     <Loader2 className="h-5 w-5 animate-spin text-[var(--color-secondary-hex)]" />
                     <span className="text-sm text-[rgb(var(--color-muted-foreground))]">Analyzing...</span>
                  </div>
                ) : predictions[employee.id] ? (
                  <RiskScore score={predictions[employee.id].riskScore} />
                ) : (
                  <button 
                    className="bg-[var(--color-secondary-hex)] text-white px-3 py-1 rounded-full text-xs font-semibold hover:opacity-80 transition-opacity"
                    onClick={(e) => { e.stopPropagation(); onSelectEmployee(employee); }}>
                    Analyze
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;