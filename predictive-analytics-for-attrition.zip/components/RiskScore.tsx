import React from 'react';

interface RiskScoreProps {
  score: number;
  size?: 'small' | 'large';
}

const RiskScore: React.FC<RiskScoreProps> = ({ score, size = 'small' }) => {
  const getRiskGradient = (s: number): string => {
    if (s > 70) return 'from-red-500 to-red-400';
    if (s > 40) return 'from-amber-500 to-amber-400';
    return 'from-green-500 to-green-400';
  };

  const getRiskTextColor = (s: number): string => {
    if (s > 70) return 'text-red-500';
    if (s > 40) return 'text-amber-500';
    return 'text-green-500';
  };

  const getRiskBgColor = (s: number): string => {
    if (s > 70) return 'bg-red-500/20';
    if (s > 40) return 'bg-amber-500/20';
    return 'bg-green-500/20';
  }

  const getRiskLabel = (s: number): string => {
    if (s > 70) return 'High';
    if (s > 40) return 'Medium';
    return 'Low';
  };

  const gradient = getRiskGradient(score);
  const textColor = getRiskTextColor(score);
  const label = getRiskLabel(score);

  if (size === 'large') {
    return (
       <div className="flex items-center gap-4">
            <span className={`text-4xl font-bold ${textColor}`}>{score}</span>
            <div className="w-full bg-[rgb(var(--color-border))] rounded-full h-4 shadow-inner">
                <div
                    className={`bg-gradient-to-r ${gradient} h-4 rounded-full transition-all duration-500`}
                    style={{ width: `${score}%` }}
                ></div>
            </div>
        </div>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getRiskBgColor(score)} ${textColor}`}>
        {score} - {label}
      </span>
      <div className="w-16 bg-[rgb(var(--color-border))] rounded-full h-1.5">
        <div
          className={`bg-gradient-to-r ${gradient} h-1.5 rounded-full transition-all duration-500`}
          style={{ width: `${score}%` }}
        ></div>
      </div>
    </div>
  );
};

export default RiskScore;