import React, { useState, useMemo, useCallback } from 'react';
import { mockEmployees } from '../services/mockData';
import { Employee, AttritionPrediction, ChartData, ResumeAnalysis } from '../types';
import { getAttritionPrediction, getResumeAnalysis } from '../services/geminiService';
import EmployeeList from './EmployeeList';
import EmployeeDetail from './EmployeeDetail';
import KpiCard from './KpiCard';
import ChartContainer from './ChartContainer';
import { TrendingUp, Users, AlertTriangle, PieChart as PieChartIcon } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const RISK_COLORS: { [key: string]: string } = {
  'High Risk': '#ef4444', // red-500
  'Medium Risk': '#f59e0b', // amber-500
  'Low Risk': '#22c55e', // green-500
};

const chartTickColors = {
    light: '#6b7280', // gray-500
    dark: '#9ca3af', // gray-400
    bright: '#4b5563', // gray-600
};

type DashboardProps = {
    theme: 'light' | 'dark' | 'bright';
}

const Dashboard: React.FC<DashboardProps> = ({ theme }) => {
  const [employees] = useState<Employee[]>(mockEmployees);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [predictions, setPredictions] = useState<Record<number, AttritionPrediction>>({});
  const [resumeAnalyses, setResumeAnalyses] = useState<Record<number, ResumeAnalysis>>({});
  const [loadingEmployeeId, setLoadingEmployeeId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSelectEmployee = useCallback(async (employee: Employee) => {
    setSelectedEmployee(employee);
    if (!predictions[employee.id]) {
      setLoadingEmployeeId(employee.id);
      setError(null);
      try {
        const prediction = await getAttritionPrediction(employee);
        setPredictions(prev => ({ ...prev, [employee.id]: prediction }));
      } catch (err: unknown) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError("An unknown error occurred.");
        }
      } finally {
        setLoadingEmployeeId(null);
      }
    }
  }, [predictions]);

  const handleAnalyzeResume = useCallback(async (employee: Employee, resumeText: string) => {
    if (!employee) return;
    setLoadingEmployeeId(employee.id);
    setError(null);
    try {
        const analysis = await getResumeAnalysis(employee, resumeText);
        setResumeAnalyses(prev => ({ ...prev, [employee.id]: analysis }));
        
        setPredictions(prev => ({
            ...prev,
            [employee.id]: {
                ...(prev[employee.id] || { riskFactors: [], retentionStrategies: [] }), // Ensure prediction exists
                riskScore: analysis.updatedRiskScore,
            }
        }));

    } catch (err: unknown) {
         if (err instanceof Error) {
            setError(err.message);
        } else {
            setError("An unknown error occurred during resume analysis.");
        }
    } finally {
        setLoadingEmployeeId(null);
    }
  }, []);

  const highRiskEmployeesCount = useMemo(() => {
    return Object.values(predictions).filter(p => p.riskScore > 70).length;
  }, [predictions]);
  
  const averageRiskScore = useMemo(() => {
    const scores = Object.values(predictions).map(p => p.riskScore);
    if (scores.length === 0) return 0;
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  }, [predictions]);

  const riskLevelData: ChartData[] = useMemo(() => {
    const levels: { [key: string]: number } = { 'Low Risk': 0, 'Medium Risk': 0, 'High Risk': 0 };
    Object.values(predictions).forEach(p => {
      if (p.riskScore <= 40) levels['Low Risk']++;
      else if (p.riskScore <= 70) levels['Medium Risk']++;
      else levels['High Risk']++;
    });
    return [
      { name: 'Low Risk', value: levels['Low Risk'] },
      { name: 'Medium Risk', value: levels['Medium Risk'] },
      { name: 'High Risk', value: levels['High Risk'] },
    ].filter(d => d.value > 0);
  }, [predictions]);

  const departmentRiskData = useMemo(() => {
    const departmentRisks: { [key: string]: { totalRisk: number, count: number } } = {};
    Object.entries(predictions).forEach(([employeeId, prediction]) => {
      const employee = employees.find(e => e.id === parseInt(employeeId));
      if (employee) {
        if (!departmentRisks[employee.department]) {
          departmentRisks[employee.department] = { totalRisk: 0, count: 0 };
        }
        departmentRisks[employee.department].totalRisk += prediction.riskScore;
        departmentRisks[employee.department].count++;
      }
    });

    return Object.entries(departmentRisks).map(([name, data]) => ({
      name,
      'Average Risk Score': Math.round(data.totalRisk / data.count),
    }));
  }, [predictions, employees]);

  const tickColor = chartTickColors[theme];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KpiCard title="Total Employees" value={employees.length} icon={<Users className="w-6 h-6 text-[var(--color-primary-hex)]" />} />
        <KpiCard title="High-Risk Employees" value={highRiskEmployeesCount} icon={<AlertTriangle className="w-6 h-6 text-red-500" />} description="Risk score > 70" />
        <KpiCard title="Avg. Risk Score" value={averageRiskScore > 0 ? `${averageRiskScore}%` : 'N/A'} icon={<TrendingUp className="w-6 h-6 text-yellow-500" />} description="Across analyzed staff" />
        <KpiCard title="Risk Distribution" value={riskLevelData.length > 0 ? '' : 'Analyze employees to see data'} icon={<PieChartIcon className="w-6 h-6 text-green-500" />} >
             {riskLevelData.length > 0 && (
                <div className="w-full h-24 -mt-4">
                    <ResponsiveContainer>
                        <PieChart>
                            <Pie data={riskLevelData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={40} innerRadius={25}>
                                {riskLevelData.map((entry) => <Cell key={`cell-${entry.name}`} fill={RISK_COLORS[entry.name] || '#ccc'} />)}
                            </Pie>
                             <Tooltip contentStyle={{
                                 backgroundColor: 'rgb(var(--color-card) / 0.8)', 
                                 borderColor: 'rgb(var(--color-border))'
                                }} 
                                labelStyle={{color: 'rgb(var(--color-card-foreground))'}}
                                formatter={(value) => [`${value} employees`, 'Count']}
                             />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            )}
        </KpiCard>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[rgb(var(--color-card))] p-6 rounded-lg shadow-md border border-black/5">
          <h3 className="text-lg font-semibold mb-4 text-[var(--color-secondary-hex)]">Employee Attrition Risk</h3>
          <EmployeeList
            employees={employees}
            onSelectEmployee={handleSelectEmployee}
            selectedEmployee={selectedEmployee}
            predictions={predictions}
            loadingEmployeeId={loadingEmployeeId}
          />
        </div>
        <div className="lg:col-span-1">
          <EmployeeDetail
            employee={selectedEmployee}
            prediction={selectedEmployee ? predictions[selectedEmployee.id] : null}
            isLoading={loadingEmployeeId !== null && loadingEmployeeId === selectedEmployee?.id}
            error={error}
            resumeAnalysis={selectedEmployee ? resumeAnalyses[selectedEmployee.id] : null}
            onAnalyzeResume={handleAnalyzeResume}
          />
        </div>
      </div>

       {Object.keys(predictions).length > 2 && departmentRiskData.length > 0 && (
          <ChartContainer title="Average Risk Score by Department">
             <ResponsiveContainer width="100%" height={300}>
              <BarChart data={departmentRiskData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#004040" stopOpacity={0.9}/>
                      <stop offset="95%" stopColor="#005f5f" stopOpacity={0.9}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tick={{ fill: tickColor }} stroke="rgb(var(--color-border))"/>
                  <YAxis tick={{ fill: tickColor }} stroke="rgb(var(--color-border))"/>
                  <Tooltip 
                    cursor={{fill: 'rgb(var(--color-secondary-hsl) / 0.1)'}} 
                    contentStyle={{
                        backgroundColor: 'rgb(var(--color-card) / 0.8)', 
                        borderColor: 'rgb(var(--color-border))'
                    }} 
                    labelStyle={{color: 'rgb(var(--color-card-foreground))'}}
                  />
                  <Legend wrapperStyle={{ color: tickColor }} />
                  <Bar dataKey="Average Risk Score" fill="url(#barGradient)" />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
       )}

    </div>
  );
};

export default Dashboard;