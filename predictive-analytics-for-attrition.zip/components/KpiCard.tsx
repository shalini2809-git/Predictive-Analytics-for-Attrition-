import React from 'react';

interface KpiCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  description?: string;
  children?: React.ReactNode;
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, icon, description, children }) => {
  return (
    <div className="bg-[rgb(var(--color-card))] p-4 rounded-lg shadow-md border border-black/5 flex flex-col justify-between transition-colors">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-[rgb(var(--color-muted-foreground))]">{title}</h3>
        {icon}
      </div>
      <div className="mt-2">
        {children ? (
            children
        ) : (
             <p className="text-2xl font-semibold text-[rgb(var(--color-card-foreground))]">{value}</p>
        )}
        {description && <p className="text-xs text-[rgb(var(--color-muted-foreground))] mt-1">{description}</p>}
      </div>
    </div>
  );
};

export default KpiCard;