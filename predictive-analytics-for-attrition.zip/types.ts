export interface Employee {
  id: number;
  name: string;
  department: 'Engineering' | 'Sales' | 'Marketing' | 'HR' | 'Product';
  role: string;
  tenureMonths: number;
  salary: number;
  performanceScore: number; // 1-5 scale
  engagementScore: number; // 1-100 scale
  lastPromotionYears: number;
}

export interface RetentionStrategy {
  strategy: string;
  rationale: string;
}

export interface AttritionPrediction {
  riskScore: number; // 0-100
  riskFactors: string[];
  retentionStrategies: RetentionStrategy[];
}

export interface ChartData {
  name: string;
  value: number;
}

export interface ResumeAnalysis {
  updatedRiskScore: number;
  analysisSummary: string;
  newRiskFactors: string[];
  positiveSignals: string[];
}
